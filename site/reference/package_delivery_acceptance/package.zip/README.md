# Declared research reproduction

Run `uv sync --locked --no-dev --python 3.12` (append the extras below), then
`uv run --no-sync python eidos-reproduce.py`. Or use `docker build -t eidos-research .`
and `docker run --rm eidos-research`. Docker Compose: `docker compose run --rm research`.
Use `docker create` / `docker cp` to retain generated outputs before removing a container.

The runner refuses changed inputs, pre-existing outputs, failed reproduction or
validator commands, missing outputs and input changes during execution. Start a
fresh copy for each run. execution-record.json records output hashes and provenance.
The manifest detects accidental changes; it is not a signed security attestation.
The declared seed and versions are recorded, not enforced inside arbitrary research code.

Binder configuration installs the same locked environment. From a Binder terminal
run `uv run --no-sync python eidos-reproduce.py`. A remote Binder launch is not
validated by package generation. Its notebook server environment is separate.

Python 3.12 and uv are external requirements for local use. Quarto, TeX, GPU drivers,
external services and data not listed in the manifest are not bundled. Projects
requiring them must provision and qualify them before claiming end-to-end execution.

Install command: `uv sync --locked --no-dev --python 3.12`
