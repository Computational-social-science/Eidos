import json
from pathlib import Path
r=json.loads(Path('result.json').read_text())
if not Path(r['implementation_path']).is_relative_to(Path.cwd()): raise SystemExit('Original checkout leaked into isolated run')
if r['verdict']!='PASS' or len(r['cases'])!=12 or len(r['negative_controls'])!=2:
    raise SystemExit('Numerical acceptance failed')
if not all(c['verdict']=='PASS' for c in r['cases']): raise SystemExit('Failed positive control')
if not all(c['rejected'] for c in r['negative_controls']): raise SystemExit('Broken control accepted')
