"""Run a declared reproduction and validator; success is not scientific certification."""
import hashlib,json,os,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path

root=Path(__file__).resolve().parent
os.chdir(root)
manifest_bytes=(root/'package-manifest.json').read_bytes()
manifest_digest=hashlib.sha256(manifest_bytes).hexdigest()
manifest=json.loads(manifest_bytes)
def require(ok,message):
    if not ok: raise SystemExit(message)
def checked(name):
    path=root/name
    require(path.resolve().is_relative_to(root) and not any(p.is_symlink() for p in [path,*path.parents] if p!=root.parent),'external or linked path: '+name)
    return path
for name,digest in manifest['sha256'].items():
    path=checked(name)
    require(path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==digest,'input checksum mismatch: '+name)
for name in manifest['outputs']+['execution-record.json']:
    path=checked(name)
    require(not path.exists(),'refusing pre-existing output: '+name)
try:
    claim=os.open(root/'.eidos-execution.lock',os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
except FileExistsError:
    raise SystemExit('package copy already claimed; use a fresh copy')
with os.fdopen(claim,'w') as stream:
    stream.write(str(os.getpid()))
for key in ('command','verify_command'):
    command=manifest[key]
    result=subprocess.run([sys.executable,*command[1:]],cwd=root)
    require(result.returncode==0,key+' failed with exit '+str(result.returncode))
outputs={}
for name in manifest['outputs']:
    path=checked(name)
    require(path.is_file(),'missing required output: '+name)
    outputs[name]=hashlib.sha256(path.read_bytes()).hexdigest()
# An executed command must not silently replace its declared inputs.
for name,digest in manifest['sha256'].items():
    path=checked(name)
    require(path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==digest,'input changed during execution: '+name)
require((root/'package-manifest.json').read_bytes()==manifest_bytes,'manifest changed during execution')
record={k:manifest[k] for k in ('seed','seed_reason','data_version','config_version','command','verify_command')}
record.update(generated=datetime.now(timezone.utc).isoformat(),python=sys.version,executable=sys.executable,outputs=outputs,
              manifest_sha256=manifest_digest,
              scope='Declared commands and output integrity only; not independent scientific certification.')
temporary=root/'.eidos-record.tmp'
with temporary.open('x',encoding='utf-8') as stream:
    stream.write(json.dumps(record,indent=2)+'\n')
os.replace(temporary,root/'execution-record.json')
print('Declared reproduction and validation completed')
