import json
from pathlib import Path
from framework.verifiers.numerics import kernel_regression_report
from framework import stable_numerics
r=kernel_regression_report()
r['implementation_path']=str(Path(stable_numerics.__file__).resolve())
Path('result.json').write_text(json.dumps(r,indent=2))
