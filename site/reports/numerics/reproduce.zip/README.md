# Eidos numerical reproduction

Published numerical kernels and a separately qualified adapted optimizer-stationarity experiment; not paper-wide training, grokking or generalisation.

uv sync --locked --extra dev
uv run --no-sync python reproduce.py
uv run --no-sync python -m pytest tests -q

Source: https://arxiv.org/html/2610.31642v3

CPU verification of the saved training run:
uv run --no-sync python -m framework.project check softmax_training

Existing MCP/agent (optional dependency):
uv sync --locked --extra dev --extra agent
uv run --no-sync python -m framework.project check barron2026_agent

To rerun training, use a CUDA environment matching reference/softmax_training/docs/evidence.json runtime.
python reference/softmax_training/train.py
This adapted stationarity experiment does not reproduce the paper's generalisation result.
