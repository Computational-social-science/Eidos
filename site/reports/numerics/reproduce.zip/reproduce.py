import hashlib,json
from pathlib import Path
from tools.numerics_case import build_case,export_case
root=Path(__file__).parent
for name,digest in json.loads((root/'checksums.json').read_text()).items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:
        raise SystemExit('Checksum mismatch: '+name)
data=build_case()
export_case(root/'regenerated',data)
print(json.dumps(data['qualification'],indent=2))
print('Regenerated all 96 displayed cases, CSV, report source and bundle in regenerated/')
raise SystemExit(0 if data['qualification']['verdict']=='PASS' else 1)
