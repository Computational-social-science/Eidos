"""Read-only training evidence gate; completion and provenance precede interpretation."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from datetime import datetime

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def qualified_backend(value: dict) -> bool:
    cases, controls = value.get("cases", []), value.get("negative_controls", [])
    return (value.get("verdict") == "PASS" and len(cases) == 12
            and all(case.get("verdict") == "PASS" for case in cases)
            and len(controls) == 2 and all(c.get("rejected") is True for c in controls))


def validate_report(report: dict, protocol: dict, *, check_files: bool = True) -> list[str]:
    errors = []
    if report.get("status") != "COMPLETE":
        errors.append("training evidence is not COMPLETE")
    runs = report.get("runs", [])
    if sorted(r.get("seed", -1) for r in runs) != sorted(protocol.get("seeds", [])) or not runs:
        errors.append("declared seeds are missing, duplicated or replaced")
    if not qualified_backend(report.get("backend_preflight", {})):
        errors.append("actual backend has not passed independent qualification")
    try:
        if datetime.fromisoformat(report["started_at"]) <= datetime.fromisoformat(protocol["registered_at"]):
            errors.append("execution did not follow prospective local registration")
    except (KeyError, TypeError, ValueError):
        errors.append("missing or invalid registration/execution times")
    steps, interval = protocol.get("distillation_steps", 0), protocol.get("log_interval", 1)
    expected = list(range(0, steps + 1, interval)) if steps > 0 and interval > 0 else []
    for run in runs:
        seed = run.get("seed")
        variants = run.get("variants", {})
        if set(variants) != {"standard", "fixed"}:
            errors.append(f"seed {seed}: both declared variants are required")
        for name, variant in variants.items():
            if variant.get("initial_state_sha256") != run.get("teacher_state_sha256"):
                errors.append(f"seed {seed}: {name} did not start at teacher weights")
            rows = variant.get("checkpoints", [])
            if [row.get("step") for row in rows] != expected or not rows:
                errors.append(f"seed {seed}: {name} checkpoint sequence is incomplete")
            for row in rows:
                for key in ("parameter_displacement_l2", "heldout_kl_float64", "test_accuracy", "teacher_agreement"):
                    value = row.get(key)
                    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                        errors.append(f"seed {seed}: non-finite or missing {key}")
                if name == "fixed" and row.get("parameter_displacement_l2") != 0:
                    errors.append(f"seed {seed}: fixed student left exact stationarity")
            if name == "fixed" and variant.get("final_state_sha256") != run.get("teacher_state_sha256"):
                errors.append(f"seed {seed}: fixed final parameter hash differs from teacher")
    if check_files:
        required = ("reference/softmax_training/protocol.json", "reference/softmax_training/train.py",
                    "reference/softmax_training/validate.py", "framework/stable_numerics_torch.py",
                    "framework/verifiers/numerics.py")
        hashes = report.get("source_sha256", {})
        for name in required:
            path = ROOT / name
            if not path.is_file() or hashes.get(name) != digest(path):
                errors.append(f"source provenance mismatch: {name}")
        for name, checksum in report.get("artifacts", {}).items():
            path = (HERE / name).resolve()
            if not path.is_relative_to(HERE) or not path.is_file() or digest(path) != checksum:
                errors.append(f"checkpoint provenance mismatch: {name}")
        if not report.get("artifacts"):
            errors.append("no model checkpoint artifacts")
    return errors


def main() -> int:
    try:
        report = json.loads((HERE / "docs/evidence.json").read_text(encoding="utf-8"))
        protocol = json.loads((HERE / "protocol.json").read_text(encoding="utf-8"))
        errors = validate_report(report, protocol)
    except (OSError, ValueError, TypeError) as exc:
        errors = [f"training evidence unavailable: {exc}"]
    print(json.dumps({"status": "FAIL" if errors else "PASS", "findings": errors}, indent=2))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
