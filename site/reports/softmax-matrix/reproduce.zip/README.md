Eidos supported loss-precision matrix. Select a Python >=3.11 environment.
uv sync --locked --extra dev --extra verifiers
uv run --no-sync python reference/softmax_matrix/verify.py
uv run --no-sync python -m pytest tests/test_softmax_matrix.py -q
The saved CPU acceptance does not rerun CUDA training. All models and original parent initial states are included.
